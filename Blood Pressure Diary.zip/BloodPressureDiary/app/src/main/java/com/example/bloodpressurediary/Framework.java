package com.example.bloodpressurediary;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Framework extends AppCompatActivity {

    Button btn_start;
    private static final int MY_CAMERA_REQUEST_CODE = 100;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_framework);

        Container.overallCtx = this;
        init();
    }


    private void init() {
        if (!Container.framework_is_ok) {
            Container.framework_is_ok = true;
            try {
                Container.musiczre = new Music(R.raw.zre_music, this);
            } catch (Exception unused) {
            }
        }

        this.btn_start = (Button) findViewById(R.id.btn_start);
        setButtonActions();


    }


    private void setButtonActions() {

        this.btn_start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                checkCameraPermission();
            }
        });
    }

    private void checkCameraPermission(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_REQUEST_CODE);
            }else {
                startCameraActivity();
            }
        }
    }

    private void startCameraActivity() {
        startActivity(CameraActivity.Companion.getIntent(this));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCameraActivity();
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }
}
