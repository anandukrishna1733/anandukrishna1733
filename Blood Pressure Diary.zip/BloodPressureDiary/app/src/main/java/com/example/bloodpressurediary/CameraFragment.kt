package com.example.bloodpressurediary

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Size
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.camera.core.CameraX
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureConfig
import androidx.camera.core.PreviewConfig
import androidx.fragment.app.Fragment
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random


class CameraFragment : Fragment() {

    private lateinit var viewFinder: TextureView

    private var imageCapture: ImageCapture? = null
    private val dateFormat = SimpleDateFormat("dd/MM/yyy hh:mm:ss aa")
    var database: SQLiteDatabase? = null
    private var dManage: DManage? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? =
        inflater.inflate(R.layout.fragment_camera, container, false)


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dManage = DManage(requireContext())
        database = dManage?.writableDatabase
        initViews(view)
    }

    private fun initViews(view: View) {
        viewFinder = view.findViewById(R.id.view_finder)
        viewFinder.post { startCamera() }
        Handler().postDelayed({
            insertRandomValue()
            Toast.makeText(
                requireContext(),
                resources.getString(R.string.addedA),
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(requireContext(), LogDiaryActivity::class.java)
            startActivity(intent)
            requireActivity().finish()
        }, 5000)
    }

    private fun startCamera() {
        // Create configuration object for the viewfinder use case
        val previewConfig = PreviewConfig.Builder().apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setTargetResolution(Size(viewFinder.width, viewFinder.width))
                setLensFacing(CameraX.LensFacing.FRONT)
            }
        }.build()

        // Build the viewfinder use case
        val preview = PreviewBuilder.build(previewConfig, viewFinder)

        // Create configuration object for the image capture use case
        val imageCaptureConfig = ImageCaptureConfig.Builder()
            .apply {
                setCaptureMode(ImageCapture.CaptureMode.MIN_LATENCY)
                    .setLensFacing(CameraX.LensFacing.FRONT)
            }.build()

        // Build the image capture use case and attach button click listener
        imageCapture = ImageCapture(imageCaptureConfig)
        CameraX.bindToLifecycle(this, preview, imageCapture)
    }

    private fun insertRandomValue(){
        val instance = Calendar.getInstance()
        instance.time = Date()
        val i = instance[1]
        val i2 = instance[2]
        val i3 = instance[5]
        val i4 = instance[11]
        val trim =""
        val strArr = arrayOfNulls<String>(10)
        strArr[0] = dateFormat.format(instance.time)
        strArr[1] = Random.nextInt(110,140).toString()
        strArr[2] = Random.nextInt(60,90).toString()
        strArr[3] = Random.nextInt(70,100).toString()
        strArr[4] = (DManage.zregMI(database) + 1).toString()
        if (strArr[1] == "") {
            strArr[1] = "-"
        }
        if (strArr[2] == "") {
            strArr[2] = "-"
        }
        if (strArr[3] == "") {
            strArr[3] = "-"
        }
        strArr[5] = trim
        strArr[6] = i3.toString()
        strArr[7] = i2.toString()
        strArr[8] = i.toString()
        strArr[9] = i4.toString()
        DManage.zaddDat(database, strArr)
    }
}
