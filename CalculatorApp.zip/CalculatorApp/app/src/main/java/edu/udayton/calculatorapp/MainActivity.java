package edu.udayton.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button calBtn = (Button)findViewById(R.id.numCalBtn);

        View.OnClickListener btnCalculatorListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent calIntent = new Intent(MainActivity.this, CalculatorActivity.class);
                startActivity(calIntent);
            }
        };
        calBtn.setOnClickListener(btnCalculatorListener);

        Button curBtn = (Button)findViewById(R.id.currConvBtn);

        View.OnClickListener btnCurrListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent curIntent = new Intent(MainActivity.this, CurrencyConversionActivity.class);
                startActivity(curIntent);
            }
        };
        curBtn.setOnClickListener(btnCurrListener);


    }
}