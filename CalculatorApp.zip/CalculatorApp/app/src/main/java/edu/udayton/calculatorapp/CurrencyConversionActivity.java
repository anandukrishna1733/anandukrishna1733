package edu.udayton.calculatorapp;

import android.app.Activity;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class CurrencyConversionActivity extends AppCompatActivity {

    private final double EURO_CONVERSION_RATE = 0.95;
    private final double PESO_CONVERSION_RATE = 20.43;
    private final double CAN_CONVERSION_RATE = 1.28;

    private final int limit = 100000;

    private double amtEntered, amtConverted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency_conversion);

        Button btConvert = (Button)findViewById(R.id.btnConvert);

        View.OnClickListener btnConvertListener = new View.OnClickListener() {
            EditText txtAmount = (EditText)findViewById(R.id.txtInpAmt);
            RadioButton radToEuro = (RadioButton)findViewById(R.id.radioCurr1);
            RadioButton radToPeso = (RadioButton)findViewById(R.id.radioCurr2) ;
            RadioButton radToCan = (RadioButton)findViewById(R.id.radioCurr3) ;
            TextView txtResult = (TextView)findViewById(R.id.textRslt);

            DecimalFormat formatter = new DecimalFormat("#######.###");

            @Override
            public void onClick(View v) {
                String inpString = txtAmount.getText().toString();
                String outString = "Invalid amount";

                try{
                    amtEntered = Double.parseDouble(inpString);
                    if(radToEuro.isChecked() && amtEntered <= limit){
                        amtConverted = amtEntered * EURO_CONVERSION_RATE;
                        outString = "Converted Amount is " + formatter.format(amtConverted) + " €";
                    }else if(radToPeso.isChecked() && amtEntered <= limit){
                        amtConverted = amtEntered * PESO_CONVERSION_RATE;
                        outString = "Converted Amount is " + formatter.format(amtConverted) + " Mex$";
                    }else if(radToCan.isChecked() && amtEntered <= limit){
                        amtConverted = amtEntered * CAN_CONVERSION_RATE;
                        outString = "Converted Amount is " + formatter.format(amtConverted) + " Can$";
                    }


                }catch(Exception e){
                    Toast myToast = Toast.makeText(CurrencyConversionActivity.this, e.toString(), Toast.LENGTH_LONG);
                    myToast.show();
                }

                txtResult.setText(outString);
            }
        };

        btConvert.setOnClickListener(btnConvertListener);

    }
}